package dev.austun.casinohelperplus.logic;

/**
 * A per-player summary rolled up from the history log. Powers the whale
 * leaderboard and the per-player breakdown. Always rebuilt from history, never
 * stored, so it can't drift out of sync.
 */
public class PlayerStats {
    public String player;
    public int betCount;
    public long totalWagered; // real wagers only (wins + losses)
    public int wins;
    public int losses;
    public int refunds;
    public int tips;
    public long tipTotal;
    public long houseNet;      // how much the house made off this player
    public long biggestBet;
    public long biggestPayout;
    public long lastSeen;

    public PlayerStats(String player) {
        this.player = player;
    }

    /** Folds one history entry into this player's totals. */
    public void add(HistoryEntry h) {
        betCount++;
        houseNet += h.houseNet;
        biggestBet = Math.max(biggestBet, h.bet);
        biggestPayout = Math.max(biggestPayout, h.payout);
        lastSeen = Math.max(lastSeen, h.timestamp);
        switch (h.result == null ? "" : h.result) {
            case "WIN" -> { wins++; totalWagered += h.bet; }
            case "LOSE" -> { losses++; totalWagered += h.bet; }
            case "REFUND" -> refunds++;
            case "TIP" -> { tips++; tipTotal += h.bet; }
            default -> { }
        }
    }
}
