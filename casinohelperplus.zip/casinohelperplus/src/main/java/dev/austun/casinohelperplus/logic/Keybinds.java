package dev.austun.casinohelperplus.logic;

import dev.austun.casinohelperplus.gui.CasinoScreen;
import dev.austun.casinohelperplus.gui.HistoryScreen;
import dev.austun.casinohelperplus.gui.SettingsScreen;
import dev.austun.casinohelperplus.util.Feedback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

/**
 * Registers the keybinds and reacts to them each tick:
 * K open manager, H toggle HUD, O settings, J history, P instant payout.
 * All are rebindable in Options &rarr; Controls.
 */
public final class Keybinds {

    public static KeyBinding openManager;
    public static KeyBinding toggleHud;
    public static KeyBinding openSettings;
    public static KeyBinding openHistory;
    public static KeyBinding payWinner;

    private Keybinds() {}

    public static void register() {
        openManager = reg("open_manager", GLFW.GLFW_KEY_K);
        toggleHud = reg("toggle_hud", GLFW.GLFW_KEY_H);
        openSettings = reg("open_settings", GLFW.GLFW_KEY_O);
        openHistory = reg("open_history", GLFW.GLFW_KEY_J);
        payWinner = reg("pay_winner", GLFW.GLFW_KEY_P);

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openManager.wasPressed()) {
                client.setScreen(new CasinoScreen());
            }
            while (openSettings.wasPressed()) {
                client.setScreen(new SettingsScreen(null));
            }
            while (openHistory.wasPressed()) {
                client.setScreen(new HistoryScreen(null));
            }
            while (toggleHud.wasPressed()) {
                ModConfig cfg = ModConfig.get();
                cfg.hudEnabled = !cfg.hudEnabled;
                ModConfig.save();
                Feedback.actionBar("Casino HUD " + (cfg.hudEnabled ? "shown" : "hidden"));
            }
            while (payWinner.wasPressed()) {
                // Instant payout of the current player at your last multiplier,
                // no GUI. Copies the /pay command straight to the clipboard.
                Session.ActionResult r = Session.get().payCurrentWinner();
                if (r.success) {
                    if (r.command != null && ModConfig.get().autoCopyPayCommand) {
                        Feedback.copyToClipboard(r.command);
                        Feedback.actionBar("Copied " + r.command + "  (T, Ctrl+V, Enter)");
                    }
                    Feedback.chat(r.message);
                    Feedback.playSuccess();
                } else {
                    Feedback.actionBar(r.message);
                    Feedback.playClick();
                }
            }
        });
    }

    // 1.21.11 replaced the old String key-category with a typed Category record.
    private static final KeyBinding.Category CATEGORY =
            KeyBinding.Category.create(Identifier.of("casinohelperplus", "main"));

    private static KeyBinding reg(String name, int key) {
        return KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.casinohelperplus." + name,
                InputUtil.Type.KEYSYM, key,
                CATEGORY));
    }
}
