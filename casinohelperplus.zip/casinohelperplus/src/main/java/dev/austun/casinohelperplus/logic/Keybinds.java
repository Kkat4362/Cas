package dev.austun.casinohelperplus.logic;

import dev.austun.casinohelperplus.gui.CasinoScreen;
import dev.austun.casinohelperplus.gui.SettingsScreen;
import dev.austun.casinohelperplus.util.Feedback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

/** Registers the three keybinds (K / H / O) and reacts to them each tick. */
public final class Keybinds {

    public static KeyBinding openManager;
    public static KeyBinding toggleHud;
    public static KeyBinding openSettings;

    private Keybinds() {}

    public static void register() {
        openManager = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.casinohelperplus.open_manager",
                InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_K,
                "category.casinohelperplus"));

        toggleHud = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.casinohelperplus.toggle_hud",
                InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_H,
                "category.casinohelperplus"));

        openSettings = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.casinohelperplus.open_settings",
                InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_O,
                "category.casinohelperplus"));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openManager.wasPressed()) {
                client.setScreen(new CasinoScreen());
            }
            while (openSettings.wasPressed()) {
                client.setScreen(new SettingsScreen(null));
            }
            while (toggleHud.wasPressed()) {
                ModConfig cfg = ModConfig.get();
                cfg.hudEnabled = !cfg.hudEnabled;
                ModConfig.save();
                Feedback.actionBar("Casino HUD " + (cfg.hudEnabled ? "shown" : "hidden"));
            }
        });
    }
}
