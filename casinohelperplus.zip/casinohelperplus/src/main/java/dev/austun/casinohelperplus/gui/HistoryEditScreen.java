package dev.austun.casinohelperplus.gui;

import dev.austun.casinohelperplus.logic.HistoryEntry;
import dev.austun.casinohelperplus.logic.Session;
import dev.austun.casinohelperplus.util.AmountUtil;
import dev.austun.casinohelperplus.util.Feedback;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

/** Edits a single history entry: result, bet amount, and (for wins) multiplier. */
public class HistoryEditScreen extends Screen {

    private static final int PANEL_W = 280;
    private static final int PANEL_H = 200;
    private static final String[] RESULTS = {"WIN", "LOSE", "REFUND", "TIP"};

    private final long entryId;
    private final Screen parent;
    private int px, py;

    private String result;
    private String betText;
    private String multText;
    private TextFieldWidget betField;
    private TextFieldWidget multField;
    private String player = "";

    public HistoryEditScreen(long entryId, Screen parent) {
        super(Text.literal("Edit Bet"));
        this.entryId = entryId;
        this.parent = parent;
    }

    @Override
    protected void init() {
        px = (this.width - PANEL_W) / 2;
        py = (this.height - PANEL_H) / 2;

        HistoryEntry h = Session.get().findHistory(entryId);
        if (h == null) { close(); return; }
        if (result == null) result = h.result;
        if (betText == null) betText = AmountUtil.format(h.bet).replace("$", "");
        if (multText == null) multText = Session.trimMultiplier(h.multiplier <= 0 ? 2 : h.multiplier);
        player = h.player;

        betField = new TextFieldWidget(this.textRenderer, px + 90, py + 52, 120, 20, Text.literal("bet"));
        betField.setText(betText);
        betField.setChangedListener(v -> betText = v);
        addDrawableChild(betField);

        multField = new TextFieldWidget(this.textRenderer, px + 90, py + 78, 120, 20, Text.literal("x"));
        multField.setText(multText);
        multField.setChangedListener(v -> multText = v);
        addDrawableChild(multField);

        addDrawableChild(ButtonWidget.builder(
                        Text.literal("Result: " + result).formatted(colorFor(result)),
                        b -> {
                            int i = 0;
                            for (int k = 0; k < RESULTS.length; k++) if (RESULTS[k].equals(result)) i = k;
                            result = RESULTS[(i + 1) % RESULTS.length];
                            reopen();
                        })
                .dimensions(px + 90, py + 26, 120, 20).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Save").formatted(Formatting.GREEN), b -> save())
                .dimensions(px + 12, py + PANEL_H - 30, 78, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Delete").formatted(Formatting.RED), b -> {
            Session.get().deleteHistory(entryId);
            Feedback.playClick();
            close();
        }).dimensions(px + 100, py + PANEL_H - 30, 78, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Cancel"), b -> close())
                .dimensions(px + 190, py + PANEL_H - 30, 78, 20).build());
    }

    private void reopen() {
        this.clearAndInit(); // rebuild widgets, keeping typed values + chosen result
    }

    private void save() {
        long bet = AmountUtil.parse(betField.getText());
        if (bet < 0) bet = 0;
        double mult;
        try {
            mult = Double.parseDouble(multField.getText().trim().replace("x", "").replace("X", ""));
        } catch (NumberFormatException e) {
            mult = 2.0;
        }
        Session.get().editHistory(entryId, result, bet, mult);
        Feedback.playSuccess();
        close();
    }

    private static Formatting colorFor(String r) {
        return switch (r) {
            case "WIN" -> Formatting.RED;
            case "LOSE" -> Formatting.GREEN;
            case "TIP" -> Formatting.LIGHT_PURPLE;
            default -> Formatting.GRAY;
        };
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        ctx.fill(0, 0, this.width, this.height, 0xC0000000); // manual dim (avoids 1.21.6+ blur pass that hides custom screens)
        ctx.fill(px, py, px + PANEL_W, py + PANEL_H, 0xE6141B22);
        ctx.fill(px, py, px + PANEL_W, py + 2, 0xFF2596BE);
        ctx.fill(px, py + PANEL_H - 2, px + PANEL_W, py + PANEL_H, 0xFF2596BE);
        super.render(ctx, mouseX, mouseY, delta);

        Text title = Text.literal("Edit Bet \u2014 " + player).formatted(Formatting.AQUA, Formatting.BOLD);
        ctx.drawText(this.textRenderer, title, px + (PANEL_W - this.textRenderer.getWidth(title)) / 2,
                py + 8, 0xFFFFFF, false);

        ctx.drawText(this.textRenderer, Text.literal("Result:").formatted(Formatting.WHITE), px + 14, py + 32, 0xFFFFFF, true);
        ctx.drawText(this.textRenderer, Text.literal("Bet:").formatted(Formatting.WHITE), px + 14, py + 58, 0xFFFFFF, true);
        ctx.drawText(this.textRenderer, Text.literal("Mult x:").formatted(
                result.equals("WIN") ? Formatting.WHITE : Formatting.DARK_GRAY), px + 14, py + 84, 0xFFFFFF, true);

        Text hint = Text.literal("Multiplier only applies to WIN").formatted(Formatting.GRAY);
        ctx.drawText(this.textRenderer, hint, px + 14, py + 108, 0xFFFFFF, false);
    }

    @Override
    public void close() {
        if (this.client != null) this.client.setScreen(parent);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
