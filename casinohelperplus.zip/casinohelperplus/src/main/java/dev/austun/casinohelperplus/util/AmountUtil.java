package dev.austun.casinohelperplus.util;

import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Parses and formats in-game currency amounts.
 *
 * <p>Supports the forms players actually type on DonutSMP, e.g.
 * {@code $1,000,000}, {@code 2.5m}, {@code 950k}, {@code 1.2B}, {@code 3T}.
 * Stored internally as a whole {@code long} (fractional coins are rounded).
 */
public final class AmountUtil {

    private static final Pattern AMOUNT = Pattern.compile(
            "\\$?\\s*([0-9][0-9,]*(?:\\.[0-9]+)?)\\s*([kmbtKMBT])?");

    private AmountUtil() {}

    /**
     * Parses a raw amount string into whole currency units.
     *
     * @return the parsed value, or {@code -1} if it could not be parsed.
     */
    public static long parse(String raw) {
        if (raw == null) return -1;
        Matcher m = AMOUNT.matcher(raw.trim());
        if (!m.matches()) return -1;

        String digits = m.group(1).replace(",", "");
        String suffix = m.group(2);

        double value;
        try {
            value = Double.parseDouble(digits);
        } catch (NumberFormatException e) {
            return -1;
        }

        double mult = switch (suffix == null ? ' ' : Character.toLowerCase(suffix.charAt(0))) {
            case 'k' -> 1_000d;
            case 'm' -> 1_000_000d;
            case 'b' -> 1_000_000_000d;
            case 't' -> 1_000_000_000_000d;
            default -> 1d;
        };

        double result = value * mult;
        if (result < 0 || result > Long.MAX_VALUE) return -1;
        return Math.round(result);
    }

    /**
     * Formats a whole amount into a compact, human-friendly string with a
     * {@code $} prefix, e.g. {@code $2.5M}, {@code $950K}, {@code $1,000}.
     */
    public static String format(long amount) {
        if (amount < 1_000) {
            return "$" + amount;
        }
        String[] units = {"K", "M", "B", "T"};
        double v = amount;
        int unit = -1;
        while (v >= 1_000 && unit < units.length - 1) {
            v /= 1_000d;
            unit++;
        }
        // one decimal place, but drop a trailing ".0"
        String num = String.format(Locale.US, "%.1f", v);
        if (num.endsWith(".0")) num = num.substring(0, num.length() - 2);
        return "$" + num + units[unit];
    }

    /**
     * Formats an amount as a plain integer string with no separators, suitable
     * for pasting into a command like {@code /pay Steve 2000000}.
     */
    public static String toCommandNumber(long amount) {
        return Long.toString(amount);
    }

    /** Formats with thousands separators, e.g. {@code 1,000,000}. */
    public static String withCommas(long amount) {
        return String.format(Locale.US, "%,d", amount);
    }
}
