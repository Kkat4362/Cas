package dev.austun.casinohelperplus.gui;

import dev.austun.casinohelperplus.logic.ModConfig;
import dev.austun.casinohelperplus.util.Feedback;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import org.joml.Matrix3x2fStack;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

/**
 * Live HUD editor. Type your IGN up top and drag the preview box anywhere on
 * screen to reposition the overlay. Everything saves as you go.
 */
public class EditHudScreen extends Screen {

    private final Screen parent;
    private TextFieldWidget ignField;

    // preview box size (roughly matches the real HUD footprint)
    private static final int BOX_W = 150;
    private static final int BOX_H = 78;

    private boolean dragging = false;
    private int dragOffsetX, dragOffsetY;

    public EditHudScreen(Screen parent) {
        super(Text.literal("Edit HUD / IGN"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        ModConfig cfg = ModConfig.get();

        ignField = new TextFieldWidget(this.textRenderer, this.width / 2 - 100, 40, 200, 20,
                Text.literal("IGN"));
        ignField.setMaxLength(16);
        ignField.setText(cfg.hostIgn == null ? "" : cfg.hostIgn);
        ignField.setChangedListener(v -> {
            cfg.hostIgn = v;
            ModConfig.save();
        });
        addDrawableChild(ignField);
        setInitialFocus(ignField);

        addDrawableChild(ButtonWidget.builder(
                        Text.literal(cfg.showIgnInHud ? "IGN in HUD: ON" : "IGN in HUD: OFF"),
                        b -> {
                            cfg.showIgnInHud = !cfg.showIgnInHud;
                            ModConfig.save();
                            reopen();
                        })
                .dimensions(this.width / 2 - 100, 66, 200, 20).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Reset position"), b -> {
            cfg.hudX = 4;
            cfg.hudY = 4;
            ModConfig.save();
        }).dimensions(this.width / 2 - 100, 92, 95, 20).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Done"), b -> close())
                .dimensions(this.width / 2 + 5, 92, 95, 20).build());
    }

    private void reopen() {
        if (this.client != null) this.client.setScreen(new EditHudScreen(parent));
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        if (super.mouseClicked(click, doubled)) return true;
        ModConfig cfg = ModConfig.get();
        if (click.button() == 0 && inPreview(click.x(), click.y(), cfg)) {
            dragging = true;
            dragOffsetX = (int) click.x() - cfg.hudX;
            dragOffsetY = (int) click.y() - cfg.hudY;
            return true;
        }
        return false;
    }

    @Override
    public boolean mouseDragged(Click click, double offsetX, double offsetY) {
        if (dragging) {
            ModConfig cfg = ModConfig.get();
            cfg.hudX = clamp((int) click.x() - dragOffsetX, 0, this.width - BOX_W);
            cfg.hudY = clamp((int) click.y() - dragOffsetY, 0, this.height - BOX_H);
            return true;
        }
        return super.mouseDragged(click, offsetX, offsetY);
    }

    @Override
    public boolean mouseReleased(Click click) {
        if (dragging && click.button() == 0) {
            dragging = false;
            ModConfig.save();
            Feedback.playClick();
            return true;
        }
        return super.mouseReleased(click);
    }

    private boolean inPreview(double mx, double my, ModConfig cfg) {
        return mx >= cfg.hudX && mx <= cfg.hudX + BOX_W && my >= cfg.hudY && my <= cfg.hudY + BOX_H;
    }

    private static int clamp(int v, int lo, int hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        ctx.fill(0, 0, this.width, this.height, 0xC0000000); // manual dim (avoids 1.21.6+ blur pass that hides custom screens)

        Text title = Text.literal("Edit HUD / IGN").formatted(Formatting.AQUA, Formatting.BOLD);
        ctx.drawText(this.textRenderer, title, this.width / 2 - this.textRenderer.getWidth(title) / 2,
                20, 0xFFFFFFFF, false);
        Text hint = Text.literal("Drag the box below to move your overlay")
                .formatted(Formatting.GRAY);
        ctx.drawText(this.textRenderer, hint, this.width / 2 - this.textRenderer.getWidth(hint) / 2,
                120, 0xFFFFFFFF, false);

        super.render(ctx, mouseX, mouseY, delta);

        // ---- live preview box ----
        ModConfig cfg = ModConfig.get();
        int x = cfg.hudX, y = cfg.hudY;
        ctx.fill(x, y, x + BOX_W, y + BOX_H, 0xB0000000);
        ctx.fill(x, y, x + BOX_W, y + 2, 0xFF2596BE);
        // outline so it's clearly grabbable
        int outline = dragging ? 0xFF43C6E8 : 0x88FFFFFF;
        ctx.fill(x, y + BOX_H, x + BOX_W, y + BOX_H + 1, outline);
        ctx.fill(x, y, x + 1, y + BOX_H, outline);
        ctx.fill(x + BOX_W - 1, y, x + BOX_W, y + BOX_H, outline);

        boolean hasIgn = cfg.showIgnInHud && cfg.hostIgn != null && !cfg.hostIgn.isBlank();
        String header = hasIgn ? cfg.hostIgn : "Casino Helper+";
        float scale = hasIgn ? 1.8f : 1.3f;

        Matrix3x2fStack ms = ctx.getMatrices();
        ms.pushMatrix();
        ms.translate((float) (x + 4), (float) (y + 5));
        ms.scale(scale, scale);
        ctx.drawText(this.textRenderer, Text.literal(header), 0, 0, hasIgn ? 0xFF43C6E8 : 0xFFFFFFFF, true);
        ms.popMatrix();

        int yy = y + 5 + (int) Math.ceil(this.textRenderer.fontHeight * scale) + 2;
        ctx.drawText(this.textRenderer, Text.literal("Profit: $0").formatted(Formatting.GREEN), x + 4, yy, 0xFFFFFFFF, true);
        ctx.drawText(this.textRenderer, Text.literal("Now: waiting for a bet").formatted(Formatting.GRAY), x + 4, yy + 10, 0xFFFFFFFF, true);
        ctx.drawText(this.textRenderer, Text.literal("W/L: 0 / 0").formatted(Formatting.WHITE), x + 4, yy + 20, 0xFFFFFFFF, true);
    }

    @Override
    public void close() {
        ModConfig.save();
        if (this.client != null) this.client.setScreen(parent);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
