package dev.austun.casinohelperplus.logic;

/**
 * One resolved bet, recorded in the payout history log. Unlike a {@link Bet}
 * (which is still pending in the queue), a {@code HistoryEntry} is a finished
 * outcome: a win, loss, refund or tip. The log is the single source of truth
 * for every running stat, so editing or deleting an entry safely recalculates
 * everything.
 *
 * <p>{@code result} is one of {@code WIN}, {@code LOSE}, {@code REFUND},
 * {@code TIP}. {@code payout} is what the host paid the player (0 for a loss or
 * tip). {@code houseNet} is the effect on the host's profit for this one bet.
 */
public class HistoryEntry {
    public long id;
    public long timestamp;
    public String player;
    public long bet;
    public String result;     // WIN | LOSE | REFUND | TIP
    public double multiplier; // meaningful for WIN, else 0
    public long payout;       // paid to player
    public long houseNet;     // change to host profit

    public HistoryEntry() {} // for Gson

    public HistoryEntry(long id, String player, long bet, String result, double multiplier) {
        this.id = id;
        this.timestamp = System.currentTimeMillis();
        this.player = player;
        this.bet = bet;
        this.result = result;
        this.multiplier = multiplier;
        recalc();
    }

    /** Recomputes payout + houseNet from the current result / bet / multiplier. */
    public void recalc() {
        switch (result == null ? "" : result) {
            case "WIN" -> {
                payout = Math.round((double) bet * multiplier);
                houseNet = bet - payout;
            }
            case "LOSE" -> {
                payout = 0;
                houseNet = bet;
            }
            case "REFUND" -> {
                payout = bet;
                houseNet = 0;
                multiplier = 0;
            }
            case "TIP" -> {
                payout = 0;
                houseNet = bet;
                multiplier = 0;
            }
            default -> {
                payout = 0;
                houseNet = 0;
            }
        }
    }
}
