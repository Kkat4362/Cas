package dev.austun.casinohelperplus;

import dev.austun.casinohelperplus.gui.CasinoHud;
import dev.austun.casinohelperplus.logic.ChatListener;
import dev.austun.casinohelperplus.logic.Keybinds;
import dev.austun.casinohelperplus.logic.ModConfig;
import dev.austun.casinohelperplus.logic.Session;
import net.fabricmc.api.ClientModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Entry point. Loads local config + session, then wires up chat detection,
 * keybinds and the HUD. Nothing here touches the network.
 */
public class CasinoHelperPlusClient implements ClientModInitializer {

    public static final String MOD_ID = "casinohelperplus";
    public static final Logger LOGGER = LoggerFactory.getLogger("CasinoHelper+");

    @Override
    public void onInitializeClient() {
        ModConfig.load();
        Session.load();

        Keybinds.register();
        ChatListener.register();
        CasinoHud.register();

        LOGGER.info("Casino Helper+ loaded \u2014 fully local, no external services.");
    }
}
