package dev.austun.casinohelperplus.gui;

import dev.austun.casinohelperplus.logic.Bet;
import dev.austun.casinohelperplus.logic.ModConfig;
import dev.austun.casinohelperplus.logic.Session;
import dev.austun.casinohelperplus.util.AmountUtil;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.ArrayList;
import java.util.List;

/** Draws the always-on session overlay. Toggle with H; move via config hudX/hudY. */
public final class CasinoHud {

    private static final int ACCENT = 0xFF2596BE;
    private static final int BG = 0xB0000000;

    private CasinoHud() {}

    public static void register() {
        HudRenderCallback.EVENT.register((context, tickCounter) -> render(context));
    }

    private static void render(DrawContext ctx) {
        ModConfig cfg = ModConfig.get();
        if (!cfg.hudEnabled) return;

        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null) return;
        if (client.options.hudHidden) return; // respect F1

        Session s = Session.get();
        TextRenderer tr = client.textRenderer;

        List<Text> lines = new ArrayList<>();
        lines.add(Text.literal("Casino Helper+").formatted(Formatting.AQUA, Formatting.BOLD));

        Bet active = s.activeBet();
        if (active != null) {
            lines.add(Text.literal("Now: " + active.player + " " + AmountUtil.format(active.amount))
                    .formatted(Formatting.YELLOW));
        } else {
            lines.add(Text.literal("Now: waiting for a bet").formatted(Formatting.GRAY));
        }

        lines.add(Text.literal("Profit: " + signed(s.netProfit))
                .formatted(s.netProfit >= 0 ? Formatting.GREEN : Formatting.RED));
        lines.add(Text.literal("Held: " + AmountUtil.format(s.heldAmount)).formatted(Formatting.WHITE));
        lines.add(Text.literal("Wagered: " + AmountUtil.format(s.wageredVolume)).formatted(Formatting.WHITE));
        lines.add(Text.literal("W/L: " + s.wins + " / " + s.losses + "   Queue: " + s.queue.size())
                .formatted(Formatting.WHITE));
        lines.add(Text.literal("Limits: " + limit(s.minBet) + " - " + limit(s.maxBet)).formatted(Formatting.GRAY));

        int width = 0;
        for (Text t : lines) width = Math.max(width, tr.getWidth(t));

        int x = cfg.hudX;
        int y = cfg.hudY;
        int pad = 4;
        int boxW = width + pad * 2;
        int boxH = lines.size() * 10 + pad * 2 - 1;

        ctx.fill(x, y, x + boxW, y + boxH, BG);
        ctx.fill(x, y, x + boxW, y + 2, ACCENT); // accent bar on top

        int yy = y + pad + 1;
        for (Text t : lines) {
            ctx.drawText(tr, t, x + pad, yy, 0xFFFFFF, true);
            yy += 10;
        }
    }

    private static String signed(long v) {
        return v < 0 ? "-" + AmountUtil.format(-v) : AmountUtil.format(v);
    }

    private static String limit(long v) {
        return v == 0 ? "off" : AmountUtil.format(v);
    }
}
