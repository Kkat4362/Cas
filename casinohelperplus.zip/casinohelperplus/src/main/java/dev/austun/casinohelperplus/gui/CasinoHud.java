package dev.austun.casinohelperplus.gui;

import dev.austun.casinohelperplus.logic.Bet;
import dev.austun.casinohelperplus.logic.ModConfig;
import dev.austun.casinohelperplus.logic.Session;
import dev.austun.casinohelperplus.util.AmountUtil;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import org.joml.Matrix3x2fStack;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.ArrayList;
import java.util.List;

/**
 * The always-on session overlay. Your IGN sits at the top, rendered large so
 * it's the first thing anyone reading a stream sees. Toggle with H, and move
 * it anywhere via the drag editor (Settings &rarr; Edit HUD / IGN).
 */
public final class CasinoHud {

    private static final int ACCENT = 0xFF2596BE;
    private static final int BG = 0xB0000000;
    private static final float IGN_SCALE = 1.8f;   // IGN pops the most
    private static final float TITLE_SCALE = 1.3f; // used when no IGN is set

    private CasinoHud() {}

    public static void register() {
        HudRenderCallback.EVENT.register((context, tickCounter) -> render(context));
    }

    private static void render(DrawContext ctx) {
        ModConfig cfg = ModConfig.get();
        if (!cfg.hudEnabled) return;

        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null) return;
        if (client.options.hudHidden) return; // respect F1

        Session s = Session.get();
        TextRenderer tr = client.textRenderer;

        boolean hasIgn = cfg.showIgnInHud && cfg.hostIgn != null && !cfg.hostIgn.isBlank();
        String headerStr = hasIgn ? cfg.hostIgn : "Casino Helper+";
        float headerScale = hasIgn ? IGN_SCALE : TITLE_SCALE;

        // ---- regular stat lines ----
        List<Text> lines = new ArrayList<>();
        if (hasIgn) {
            lines.add(Text.literal("Casino Helper+").formatted(Formatting.AQUA));
        }

        Bet active = s.activeBet();
        if (active != null) {
            lines.add(Text.literal("Now: " + active.player + " " + AmountUtil.format(active.amount))
                    .formatted(Formatting.YELLOW));
        } else {
            lines.add(Text.literal("Now: waiting for a bet").formatted(Formatting.GRAY));
        }
        lines.add(Text.literal("Profit: " + signed(s.netProfit))
                .formatted(s.netProfit >= 0 ? Formatting.GREEN : Formatting.RED));
        lines.add(Text.literal("Held: " + AmountUtil.format(s.heldAmount)).formatted(Formatting.WHITE));
        lines.add(Text.literal("Wagered: " + AmountUtil.format(s.wageredVolume)).formatted(Formatting.WHITE));
        lines.add(Text.literal("W/L: " + s.wins + " / " + s.losses + "   Queue: " + s.queue.size())
                .formatted(Formatting.WHITE));
        lines.add(Text.literal("Limits: " + limit(s.minBet) + " - " + limit(s.maxBet)).formatted(Formatting.GRAY));

        // ---- measure ----
        int pad = 4;
        int headerW = (int) Math.ceil(tr.getWidth(headerStr) * headerScale);
        int headerH = (int) Math.ceil(tr.fontHeight * headerScale) + 2;
        int width = headerW;
        for (Text t : lines) width = Math.max(width, tr.getWidth(t));

        int x = cfg.hudX;
        int y = cfg.hudY;
        int boxW = width + pad * 2;
        int boxH = headerH + lines.size() * 10 + pad * 2 - 1;

        // ---- background + accent ----
        ctx.fill(x, y, x + boxW, y + boxH, BG);
        ctx.fill(x, y, x + boxW, y + 2, ACCENT);

        // ---- stat lines (drawn first, with a clean matrix) ----
        int yy = y + pad + 1 + headerH;
        for (Text t : lines) {
            ctx.drawText(tr, t, x + pad, yy, 0xFFFFFF, true);
            yy += 10;
        }

        // ---- header (scaled, drawn last so its transform can't affect the lines) ----
        Matrix3x2fStack ms = ctx.getMatrices();
        ms.pushMatrix();
        ms.translate((float) (x + pad), (float) (y + pad + 1));
        ms.scale(headerScale, headerScale);
        int headerColor = hasIgn ? 0xFF43C6E8 : 0xFFFFFFFF;
        ctx.drawText(tr, Text.literal(headerStr), 0, 0, headerColor, true);
        ms.popMatrix();
    }

    private static String signed(long v) {
        return v < 0 ? "-" + AmountUtil.format(-v) : AmountUtil.format(v);
    }

    private static String limit(long v) {
        return v == 0 ? "off" : AmountUtil.format(v);
    }
}
