package dev.austun.casinohelperplus.gui;

import dev.austun.casinohelperplus.logic.HistoryEntry;
import dev.austun.casinohelperplus.logic.Session;
import dev.austun.casinohelperplus.util.AmountUtil;
import dev.austun.casinohelperplus.util.Feedback;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.List;

/**
 * The payout history log, newest first, fully editable. Fix a mis-recorded
 * bet with Edit, or remove it with X — every stat recalculates instantly.
 */
public class HistoryScreen extends Screen {

    private static final int PANEL_W = 360;
    private static final int PANEL_H = 240;
    private static final int PER_PAGE = 7;
    private static int page = 0;

    private final Screen parent;
    private int px, py;

    public HistoryScreen(Screen parent) {
        super(Text.literal("Payout History"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        px = (this.width - PANEL_W) / 2;
        py = (this.height - PANEL_H) / 2;

        Session s = Session.get();
        List<HistoryEntry> all = s.history;
        int total = all.size();
        int maxPage = Math.max(0, (total - 1) / PER_PAGE);
        if (page > maxPage) page = maxPage;
        if (page < 0) page = 0;

        // newest first
        int start = page * PER_PAGE;
        for (int i = 0; i < PER_PAGE; i++) {
            int idx = total - 1 - (start + i);
            if (idx < 0) break;
            HistoryEntry h = all.get(idx);
            int rowY = py + 34 + i * 24;

            addDrawableChild(ButtonWidget.builder(Text.literal("Edit"), b -> {
                if (this.client != null) this.client.setScreen(new HistoryEditScreen(h.id, this));
            }).dimensions(px + PANEL_W - 96, rowY, 48, 20).build());

            addDrawableChild(ButtonWidget.builder(Text.literal("X").formatted(Formatting.RED), b -> {
                Session.get().deleteHistory(h.id);
                Feedback.playClick();
                refresh();
            }).dimensions(px + PANEL_W - 44, rowY, 20, 20).build());
        }

        // ---- footer ----
        addDrawableChild(ButtonWidget.builder(Text.literal("< Prev"), b -> {
            if (page > 0) { page--; refresh(); }
        }).dimensions(px + 8, py + PANEL_H - 28, 56, 20).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Next >"), b -> {
            page++;
            refresh();
        }).dimensions(px + 68, py + PANEL_H - 28, 56, 20).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Export CSV"), b -> {
            String path = Session.get().exportCsv();
            if (path != null) {
                Feedback.chat("Exported CSV to: " + path);
                Feedback.playSuccess();
            } else {
                Feedback.actionBar("Export failed.");
            }
        }).dimensions(px + 130, py + PANEL_H - 28, 90, 20).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Players"), b -> {
            if (this.client != null) this.client.setScreen(new LeaderboardScreen(this));
        }).dimensions(px + 224, py + PANEL_H - 28, 60, 20).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Back"), b -> close())
                .dimensions(px + 288, py + PANEL_H - 28, 64, 20).build());
    }

    private void refresh() {
        if (this.client != null) this.client.setScreen(new HistoryScreen(parent));
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        this.renderBackground(ctx, mouseX, mouseY, delta);
        ctx.fill(px, py, px + PANEL_W, py + PANEL_H, 0xE6141B22);
        ctx.fill(px, py, px + PANEL_W, py + 2, 0xFF2596BE);
        ctx.fill(px, py + PANEL_H - 2, px + PANEL_W, py + PANEL_H, 0xFF2596BE);
        super.render(ctx, mouseX, mouseY, delta);

        Session s = Session.get();
        List<HistoryEntry> all = s.history;
        int total = all.size();

        Text title = Text.literal("Payout History (" + total + ")")
                .formatted(Formatting.AQUA, Formatting.BOLD);
        ctx.drawText(this.textRenderer, title, px + 8, py + 8, 0xFFFFFF, false);

        int maxPage = Math.max(0, (total - 1) / PER_PAGE);
        Text pageText = Text.literal("Page " + (page + 1) + "/" + (maxPage + 1)).formatted(Formatting.GRAY);
        ctx.drawText(this.textRenderer, pageText,
                px + PANEL_W - 8 - this.textRenderer.getWidth(pageText), py + 10, 0xFFFFFF, false);

        if (total == 0) {
            Text empty = Text.literal("No bets recorded yet.").formatted(Formatting.DARK_GRAY);
            ctx.drawText(this.textRenderer, empty, px + 12, py + 40, 0xFFFFFF, false);
            return;
        }

        int start = page * PER_PAGE;
        for (int i = 0; i < PER_PAGE; i++) {
            int idx = total - 1 - (start + i);
            if (idx < 0) break;
            HistoryEntry h = all.get(idx);
            int rowY = py + 38 + i * 24;

            Formatting c = switch (h.result) {
                case "WIN" -> Formatting.RED;      // a win for the player costs the house
                case "LOSE" -> Formatting.GREEN;   // a loss for the player pays the house
                case "REFUND" -> Formatting.GRAY;
                case "TIP" -> Formatting.LIGHT_PURPLE;
                default -> Formatting.WHITE;
            };
            String tag = h.result.equals("WIN") ? ("WIN x" + Session.trimMultiplier(h.multiplier)) : h.result;
            ctx.drawText(this.textRenderer,
                    Text.literal(h.player + "  " + AmountUtil.format(h.bet)).formatted(Formatting.WHITE),
                    px + 10, rowY, 0xFFFFFF, true);
            ctx.drawText(this.textRenderer,
                    Text.literal(tag + "  " + signed(h.houseNet)).formatted(c),
                    px + 10, rowY + 10, 0xFFFFFF, true);
        }
    }

    private static String signed(long v) {
        return v < 0 ? "-" + AmountUtil.format(-v) : "+" + AmountUtil.format(v);
    }

    @Override
    public void close() {
        if (this.client != null) this.client.setScreen(parent);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
