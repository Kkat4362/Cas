package dev.austun.casinohelperplus.gui;

import dev.austun.casinohelperplus.logic.PlayerStats;
import dev.austun.casinohelperplus.logic.Session;
import dev.austun.casinohelperplus.util.AmountUtil;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.List;

/**
 * The whale leaderboard: players ranked by total volume wagered, with their
 * win/loss split and how much the house has netted from each.
 */
public class LeaderboardScreen extends Screen {

    private static final int PANEL_W = 360;
    private static final int PANEL_H = 240;
    private static final int PER_PAGE = 8;
    private static int page = 0;

    private final Screen parent;
    private int px, py;

    public LeaderboardScreen(Screen parent) {
        super(Text.literal("Whale Leaderboard"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        px = (this.width - PANEL_W) / 2;
        py = (this.height - PANEL_H) / 2;

        int total = Session.get().leaderboard().size();
        int maxPage = Math.max(0, (total - 1) / PER_PAGE);
        if (page > maxPage) page = maxPage;
        if (page < 0) page = 0;

        addDrawableChild(ButtonWidget.builder(Text.literal("< Prev"), b -> {
            if (page > 0) { page--; refresh(); }
        }).dimensions(px + 8, py + PANEL_H - 28, 60, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Next >"), b -> {
            page++;
            refresh();
        }).dimensions(px + 72, py + PANEL_H - 28, 60, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Back"), b -> close())
                .dimensions(px + PANEL_W - 72, py + PANEL_H - 28, 64, 20).build());
    }

    private void refresh() {
        if (this.client != null) this.client.setScreen(new LeaderboardScreen(parent));
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        ctx.fill(0, 0, this.width, this.height, 0xC0000000); // manual dim (avoids 1.21.6+ blur pass that hides custom screens)
        ctx.fill(px, py, px + PANEL_W, py + PANEL_H, 0xE6141B22);
        ctx.fill(px, py, px + PANEL_W, py + 2, 0xFF2596BE);
        ctx.fill(px, py + PANEL_H - 2, px + PANEL_W, py + PANEL_H, 0xFF2596BE);
        super.render(ctx, mouseX, mouseY, delta);

        Text title = Text.literal("Whale Leaderboard").formatted(Formatting.AQUA, Formatting.BOLD);
        ctx.drawText(this.textRenderer, title, px + 8, py + 8, 0xFFFFFFFF, false);

        // column headers
        ctx.drawText(this.textRenderer, Text.literal("Player").formatted(Formatting.GRAY), px + 24, py + 24, 0xFFFFFFFF, true);
        ctx.drawText(this.textRenderer, Text.literal("Wagered").formatted(Formatting.GRAY), px + 150, py + 24, 0xFFFFFFFF, true);
        ctx.drawText(this.textRenderer, Text.literal("W/L").formatted(Formatting.GRAY), px + 232, py + 24, 0xFFFFFFFF, true);
        ctx.drawText(this.textRenderer, Text.literal("House").formatted(Formatting.GRAY), px + 290, py + 24, 0xFFFFFFFF, true);

        List<PlayerStats> lb = Session.get().leaderboard();
        int total = lb.size();
        int maxPage = Math.max(0, (total - 1) / PER_PAGE);
        Text pageText = Text.literal("Page " + (page + 1) + "/" + (maxPage + 1)).formatted(Formatting.GRAY);
        ctx.drawText(this.textRenderer, pageText,
                px + PANEL_W - 8 - this.textRenderer.getWidth(pageText), py + 10, 0xFFFFFFFF, false);

        if (total == 0) {
            ctx.drawText(this.textRenderer, Text.literal("No players yet.").formatted(Formatting.DARK_GRAY),
                    px + 12, py + 40, 0xFFFFFFFF, false);
            return;
        }

        int start = page * PER_PAGE;
        for (int i = 0; i < PER_PAGE; i++) {
            int idx = start + i;
            if (idx >= total) break;
            PlayerStats p = lb.get(idx);
            int rowY = py + 40 + i * 20;
            int rank = idx + 1;

            Formatting rankColor = switch (rank) {
                case 1 -> Formatting.GOLD;
                case 2 -> Formatting.WHITE;
                case 3 -> Formatting.YELLOW;
                default -> Formatting.DARK_GRAY;
            };
            ctx.drawText(this.textRenderer, Text.literal("#" + rank).formatted(rankColor), px + 8, rowY, 0xFFFFFFFF, true);
            ctx.drawText(this.textRenderer, Text.literal(trim(p.player)).formatted(Formatting.WHITE), px + 24, rowY, 0xFFFFFFFF, true);
            ctx.drawText(this.textRenderer, Text.literal(AmountUtil.format(p.totalWagered)).formatted(Formatting.AQUA), px + 150, rowY, 0xFFFFFFFF, true);
            ctx.drawText(this.textRenderer, Text.literal(p.wins + "/" + p.losses).formatted(Formatting.GRAY), px + 232, rowY, 0xFFFFFFFF, true);
            ctx.drawText(this.textRenderer,
                    Text.literal(signed(p.houseNet)).formatted(p.houseNet >= 0 ? Formatting.GREEN : Formatting.RED),
                    px + 285, rowY, 0xFFFFFFFF, true);
        }
    }

    private static String trim(String name) {
        if (name == null) return "?";
        return name.length() > 16 ? name.substring(0, 15) + "\u2026" : name;
    }

    private static String signed(long v) {
        return v < 0 ? "-" + AmountUtil.format(-v) : "+" + AmountUtil.format(v);
    }

    @Override
    public void close() {
        if (this.client != null) this.client.setScreen(parent);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
