package dev.austun.casinohelperplus.logic;

/**
 * A single wager sitting in the queue: who paid, how much, and when it arrived.
 * Oversized payments are broken into several {@code Bet} chunks, so one payment
 * can produce more than one of these.
 */
public class Bet {
    public String player;
    public long amount;
    public long timestamp;

    public Bet() {} // for Gson

    public Bet(String player, long amount) {
        this.player = player;
        this.amount = amount;
        this.timestamp = System.currentTimeMillis();
    }
}
