package dev.austun.casinohelperplus.util;

import dev.austun.casinohelperplus.logic.ModConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

/**
 * Small helpers for talking back to the player: copies to clipboard, plays UI
 * sounds and prints teal-branded chat / action-bar messages. All of these
 * respect the user's settings so nothing is forced on them.
 */
public final class Feedback {

    public static final int ACCENT = 0x2596BE; // teal brand color

    private Feedback() {}

    public static void copyToClipboard(String text) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.keyboard != null) {
            client.keyboard.setClipboard(text);
        }
    }

    public static void playClick() {
        if (!ModConfig.get().soundEffects) return;
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.getSoundManager() != null) {
            client.getSoundManager().play(
                    PositionedSoundInstance.master(SoundEvents.UI_BUTTON_CLICK, 1.0F));
        }
    }

    public static void playSuccess() {
        if (!ModConfig.get().soundEffects) return;
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.getSoundManager() != null) {
            client.getSoundManager().play(
                    PositionedSoundInstance.master(SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, 1.4F));
        }
    }

    /** A distinct bell so you never miss a new bet scrolling past in chat. */
    public static void playNewBet() {
        ModConfig cfg = ModConfig.get();
        if (!cfg.soundEffects || !cfg.newBetSound) return;
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.getSoundManager() != null) {
            client.getSoundManager().play(
                    PositionedSoundInstance.master(SoundEvents.BLOCK_NOTE_BLOCK_BELL, 1.2F));
        }
    }

    /** Prints a branded message into the chat window (client-side only). */
    public static void chat(String message) {
        if (!ModConfig.get().chatFeedback) return;
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null) return;
        Text prefix = Text.literal("[Casino+] ").formatted(Formatting.AQUA);
        client.player.sendMessage(prefix.copy().append(Text.literal(message).formatted(Formatting.WHITE)), false);
    }

    /** Shows a short message above the hotbar. */
    public static void actionBar(String message) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null) return;
        client.player.sendMessage(Text.literal(message).formatted(Formatting.AQUA), true);
    }
}
