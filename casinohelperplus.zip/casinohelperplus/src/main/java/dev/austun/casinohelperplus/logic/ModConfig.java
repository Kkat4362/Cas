package dev.austun.casinohelperplus.logic;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * User-facing settings. Persisted as JSON in
 * {@code .minecraft/config/casinohelperplus/config.json}.
 *
 * <p>Everything the mod reads from chat or writes as a command is configurable
 * here, so if DonutSMP ever changes its message wording you can fix detection
 * without waiting for a mod update.
 */
public class ModConfig {

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static ModConfig INSTANCE;

    // ---- behaviour toggles ----
    public boolean soundEffects = true;
    public boolean chatFeedback = true;
    public boolean hudEnabled = true;
    public boolean autoCopyPayCommand = true;
    public boolean newBetSound = true;   // distinct chime when a bet arrives

    // ---- host identity ----
    public String hostIgn = "";          // your IGN, shown large in the HUD
    public boolean showIgnInHud = true;

    // ---- defaults applied to a fresh session ----
    public long defaultMinBet = 0L;      // 0 = no minimum
    public long defaultMaxBet = 0L;      // 0 = no maximum (no auto-split)
    public String defaultMultiplier = "2";
    public String lastMultiplier = "2";  // remembered for the one-key payout

    // ---- detection & command templates (advanced) ----
    /**
     * Regex run against every incoming game chat line. Group 1 must capture the
     * paying player's name, group 2 the amount. Case-insensitive by default.
     */
    public String payMessageRegex = "(?i)([A-Za-z0-9_]{2,16})\\s+paid you\\s+(\\$?[0-9][0-9,.]*[kmbtKMBT]?)";

    /** Placeholders: %player% and %amount% (amount is a plain integer). */
    public String payCommandTemplate = "/pay %player% %amount%";

    // ---- HUD position (top-left origin, in scaled pixels) ----
    public int hudX = 4;
    public int hudY = 4;

    public static ModConfig get() {
        if (INSTANCE == null) load();
        return INSTANCE;
    }

    private static Path path() {
        Path dir = FabricLoader.getInstance().getConfigDir().resolve("casinohelperplus");
        try {
            Files.createDirectories(dir);
        } catch (IOException ignored) {
        }
        return dir.resolve("config.json");
    }

    public static void load() {
        Path p = path();
        if (Files.exists(p)) {
            try (Reader r = Files.newBufferedReader(p)) {
                INSTANCE = GSON.fromJson(r, ModConfig.class);
            } catch (Exception e) {
                INSTANCE = null;
            }
        }
        if (INSTANCE == null) {
            INSTANCE = new ModConfig();
            save();
        }
    }

    public static void save() {
        if (INSTANCE == null) return;
        try (Writer w = Files.newBufferedWriter(path())) {
            GSON.toJson(INSTANCE, w);
        } catch (IOException ignored) {
        }
    }
}
