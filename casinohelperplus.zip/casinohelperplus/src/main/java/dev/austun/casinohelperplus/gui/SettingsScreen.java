package dev.austun.casinohelperplus.gui;

import dev.austun.casinohelperplus.logic.ModConfig;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

/** Simple toggle menu (O). Every change is saved immediately. */
public class SettingsScreen extends Screen {

    private static final int PANEL_W = 260;
    private static final int PANEL_H = 244;

    private final Screen parent;
    private int px, py;

    public SettingsScreen(Screen parent) {
        super(Text.literal("Casino Helper+ Settings"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        px = (this.width - PANEL_W) / 2;
        py = (this.height - PANEL_H) / 2;
        ModConfig cfg = ModConfig.get();
        int w = PANEL_W - 40;
        int x = px + 20;

        addDrawableChild(toggle("Sound effects", cfg.soundEffects, x, py + 30, w, b -> {
            cfg.soundEffects = !cfg.soundEffects;
            saveAndRefresh();
        }));
        addDrawableChild(toggle("Chat feedback", cfg.chatFeedback, x, py + 54, w, b -> {
            cfg.chatFeedback = !cfg.chatFeedback;
            saveAndRefresh();
        }));
        addDrawableChild(toggle("HUD overlay", cfg.hudEnabled, x, py + 78, w, b -> {
            cfg.hudEnabled = !cfg.hudEnabled;
            saveAndRefresh();
        }));
        addDrawableChild(toggle("Auto-copy pay command", cfg.autoCopyPayCommand, x, py + 102, w, b -> {
            cfg.autoCopyPayCommand = !cfg.autoCopyPayCommand;
            saveAndRefresh();
        }));
        addDrawableChild(toggle("New-bet sound", cfg.newBetSound, x, py + 126, w, b -> {
            cfg.newBetSound = !cfg.newBetSound;
            saveAndRefresh();
        }));

        addDrawableChild(ButtonWidget.builder(
                        Text.literal("Edit HUD / IGN").formatted(Formatting.AQUA),
                        b -> {
                            if (this.client != null) this.client.setScreen(new EditHudScreen(this));
                        })
                .dimensions(x, py + 154, w, 20).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Back"), b -> close())
                .dimensions(px + (PANEL_W - 100) / 2, py + PANEL_H - 30, 100, 20).build());
    }

    private ButtonWidget toggle(String label, boolean value, int x, int y, int w, ButtonWidget.PressAction onPress) {
        Text state = value
                ? Text.literal("ON").formatted(Formatting.GREEN)
                : Text.literal("OFF").formatted(Formatting.RED);
        Text text = Text.literal(label + ": ").append(state);
        return ButtonWidget.builder(text, onPress).dimensions(x, y, w, 20).build();
    }

    private void saveAndRefresh() {
        ModConfig.save();
        if (this.client != null) this.client.setScreen(new SettingsScreen(parent));
    }

    @Override
    public void close() {
        if (this.client != null) this.client.setScreen(parent);
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        ctx.fill(0, 0, this.width, this.height, 0xC0000000); // manual dim (avoids 1.21.6+ blur pass that hides custom screens)
        ctx.fill(px, py, px + PANEL_W, py + PANEL_H, 0xE6141B22);
        ctx.fill(px, py, px + PANEL_W, py + 2, 0xFF2596BE);
        ctx.fill(px, py + PANEL_H - 2, px + PANEL_W, py + PANEL_H, 0xFF2596BE);
        super.render(ctx, mouseX, mouseY, delta);

        Text title = Text.literal("Settings").formatted(Formatting.AQUA, Formatting.BOLD);
        ctx.drawText(this.textRenderer, title, px + (PANEL_W - this.textRenderer.getWidth(title)) / 2,
                py + 10, 0xFFFFFF, false);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
