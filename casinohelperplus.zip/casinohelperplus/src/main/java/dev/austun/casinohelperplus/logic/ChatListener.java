package dev.austun.casinohelperplus.logic;

import dev.austun.casinohelperplus.util.AmountUtil;
import dev.austun.casinohelperplus.util.Feedback;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Watches incoming game chat for payments and feeds them to the session.
 * The pattern is read from config, so it can be fixed by the user if the
 * server ever changes its wording. Compiled lazily and cached.
 */
public final class ChatListener {

    private static Pattern cached;
    private static String cachedFrom;

    private ChatListener() {}

    public static void register() {
        ClientReceiveMessageEvents.GAME.register((message, overlay) -> {
            if (overlay) return; // ignore action-bar text
            handle(message.getString());
        });
    }

    /** Package-visible so it can be unit-tested without a running client. */
    public static Session.ActionResult handle(String text) {
        if (text == null || text.isBlank()) return null;

        Pattern p = pattern(ModConfig.get().payMessageRegex);
        if (p == null) return null;

        Matcher m = p.matcher(text);
        if (!m.find()) return null;

        String player = m.group(1);
        long amount = AmountUtil.parse(m.group(2));
        if (player == null || amount <= 0) return null;

        Session.ActionResult result = Session.get().onPayment(player, amount);
        Feedback.chat(result.message);
        Feedback.playNewBet();
        return result;
    }

    private static Pattern pattern(String regex) {
        if (cached == null || !regex.equals(cachedFrom)) {
            try {
                cached = Pattern.compile(regex);
                cachedFrom = regex;
            } catch (Exception e) {
                cached = null;
            }
        }
        return cached;
    }
}
