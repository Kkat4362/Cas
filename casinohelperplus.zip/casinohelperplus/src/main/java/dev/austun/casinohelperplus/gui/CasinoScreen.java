package dev.austun.casinohelperplus.gui;

import dev.austun.casinohelperplus.logic.Bet;
import dev.austun.casinohelperplus.logic.ModConfig;
import dev.austun.casinohelperplus.logic.Session;
import dev.austun.casinohelperplus.util.AmountUtil;
import dev.austun.casinohelperplus.util.Feedback;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

/**
 * The casino host's control panel. Adjust limits, resolve the active bet, and
 * watch the queue and stats. Recreated after each action so displayed values
 * are always current.
 */
public class CasinoScreen extends Screen {

    private static final long[] STEPS = {100_000L, 500_000L, 1_000_000L, 5_000_000L, 10_000_000L};
    private static int stepIndex = 2;              // shared across reopens
    private static String multiplierText = null;   // remembers last multiplier

    private static final int PANEL_W = 320;
    private static final int PANEL_H = 250;

    private int px, py;
    private TextFieldWidget multiplierField;

    public CasinoScreen() {
        super(Text.literal("Casino Helper+"));
        if (multiplierText == null) multiplierText = ModConfig.get().defaultMultiplier;
    }

    private long step() {
        return STEPS[stepIndex];
    }

    @Override
    protected void init() {
        px = (this.width - PANEL_W) / 2;
        py = (this.height - PANEL_H) / 2;
        Session s = Session.get();

        // ---- min / max controls ----
        addDrawableChild(smallButton("-", px + 96, py + 28, b -> {
            s.adjustMin(-step());
            refresh();
        }));
        addDrawableChild(smallButton("+", px + 118, py + 28, b -> {
            s.adjustMin(step());
            refresh();
        }));
        addDrawableChild(smallButton("-", px + 250, py + 28, b -> {
            s.adjustMax(-step());
            refresh();
        }));
        addDrawableChild(smallButton("+", px + 272, py + 28, b -> {
            s.adjustMax(step());
            refresh();
        }));

        // ---- step size cycle ----
        addDrawableChild(ButtonWidget.builder(
                        Text.literal("Step: " + AmountUtil.format(step())),
                        b -> {
                            stepIndex = (stepIndex + 1) % STEPS.length;
                            refresh();
                        })
                .dimensions(px + (PANEL_W - 150) / 2, py + 50, 150, 18).build());

        // ---- multiplier field ----
        multiplierField = new TextFieldWidget(this.textRenderer, px + 88, py + 82, 54, 18,
                Text.literal("multiplier"));
        multiplierField.setText(multiplierText);
        multiplierField.setChangedListener(v -> multiplierText = v);
        addDrawableChild(multiplierField);
        setInitialFocus(multiplierField);

        // ---- resolve buttons ----
        addDrawableChild(colorButton("WIN", Formatting.GREEN, px + 8, py + 108, 72, b -> doWin()));
        addDrawableChild(colorButton("LOSE", Formatting.RED, px + 84, py + 108, 72, b -> apply(s.resolveLose())));
        addDrawableChild(ButtonWidget.builder(Text.literal("Refund"), b -> apply(s.refundActive()))
                .dimensions(px + 160, py + 108, 70, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Tip $"), b -> apply(s.donateActive()))
                .dimensions(px + 234, py + 108, 78, 20).build());

        // ---- bottom row ----
        addDrawableChild(ButtonWidget.builder(Text.literal("Undo"), b -> apply(s.undo()))
                .dimensions(px + 8, py + PANEL_H - 30, 54, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Void All"), b -> {
            s.voidQueue();
            Feedback.playClick();
            refresh();
        }).dimensions(px + 64, py + PANEL_H - 30, 54, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Reset"), b -> {
            s.resetStats();
            Feedback.playClick();
            refresh();
        }).dimensions(px + 120, py + PANEL_H - 30, 52, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Settings"), b -> {
            if (this.client != null) this.client.setScreen(new SettingsScreen(new CasinoScreen()));
        }).dimensions(px + 174, py + PANEL_H - 30, 64, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Close"), b -> close())
                .dimensions(px + 240, py + PANEL_H - 30, 72, 20).build());
    }

    // ------------------------------------------------------------ actions

    private void doWin() {
        String raw = multiplierField.getText().trim().replace("x", "").replace("X", "");
        double m;
        try {
            m = Double.parseDouble(raw);
        } catch (NumberFormatException e) {
            Feedback.actionBar("Enter a valid multiplier (e.g. 2 or 2.5)");
            Feedback.playClick();
            return;
        }
        apply(Session.get().resolveWin(m));
    }

    private void apply(Session.ActionResult r) {
        if (r == null) return;
        if (r.success) {
            if (r.command != null && ModConfig.get().autoCopyPayCommand) {
                Feedback.copyToClipboard(r.command);
                Feedback.chat("Copied \u2192 " + r.command + "  (press T, Ctrl+V, Enter)");
            }
            Feedback.chat(r.message);
            Feedback.playSuccess();
        } else {
            Feedback.actionBar(r.message);
            Feedback.playClick();
        }
        refresh();
    }

    private void refresh() {
        if (this.client != null) this.client.setScreen(new CasinoScreen());
    }

    // ------------------------------------------------------------ rendering

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        // dim the world, draw the panel (under widgets), then widgets, then text on top
        this.renderBackground(ctx, mouseX, mouseY, delta);
        ctx.fill(px, py, px + PANEL_W, py + PANEL_H, 0xE6141B22);
        ctx.fill(px, py, px + PANEL_W, py + 2, 0xFF2596BE);
        ctx.fill(px, py + PANEL_H - 2, px + PANEL_W, py + PANEL_H, 0xFF2596BE);
        super.render(ctx, mouseX, mouseY, delta);

        Session s = Session.get();

        Text title = Text.literal("Casino Helper+").formatted(Formatting.AQUA, Formatting.BOLD);
        ctx.drawText(this.textRenderer, title, px + (PANEL_W - this.textRenderer.getWidth(title)) / 2,
                py + 8, 0xFFFFFF, false);

        ctx.drawText(this.textRenderer, Text.literal("Min: " + limit(s.minBet)).formatted(Formatting.WHITE),
                px + 8, py + 32, 0xFFFFFF, true);
        ctx.drawText(this.textRenderer, Text.literal("Max: " + limit(s.maxBet)).formatted(Formatting.WHITE),
                px + 162, py + 32, 0xFFFFFF, true);

        // active bet
        Bet active = s.activeBet();
        Text activeText = (active == null)
                ? Text.literal("Active bet: none").formatted(Formatting.GRAY)
                : Text.literal("Active: " + active.player + "  " + AmountUtil.format(active.amount))
                        .formatted(Formatting.YELLOW, Formatting.BOLD);
        ctx.drawText(this.textRenderer, activeText, px + 8, py + 72, 0xFFFFFF, true);

        ctx.drawText(this.textRenderer, Text.literal("Payout x").formatted(Formatting.GRAY),
                px + 8, py + 87, 0xFFFFFF, true);

        // queue preview
        ctx.drawText(this.textRenderer, Text.literal("Queue (" + s.queue.size() + "):").formatted(Formatting.AQUA),
                px + 8, py + 136, 0xFFFFFF, true);
        int shown = Math.min(4, s.queue.size());
        for (int i = 0; i < shown; i++) {
            Bet b = s.queue.get(i);
            Formatting c = (i == 0) ? Formatting.YELLOW : Formatting.GRAY;
            ctx.drawText(this.textRenderer,
                    Text.literal((i + 1) + ". " + b.player + "  " + AmountUtil.format(b.amount)).formatted(c),
                    px + 12, py + 148 + i * 10, 0xFFFFFF, true);
        }
        if (s.queue.size() > 4) {
            ctx.drawText(this.textRenderer,
                    Text.literal("...and " + (s.queue.size() - 4) + " more").formatted(Formatting.DARK_GRAY),
                    px + 12, py + 148 + 4 * 10, 0xFFFFFF, true);
        }

        // stats
        Text profit = Text.literal("Profit: " + signed(s.netProfit))
                .formatted(s.netProfit >= 0 ? Formatting.GREEN : Formatting.RED);
        ctx.drawText(this.textRenderer, profit, px + 8, py + 196, 0xFFFFFF, true);
        ctx.drawText(this.textRenderer,
                Text.literal("Held: " + AmountUtil.format(s.heldAmount)).formatted(Formatting.WHITE),
                px + 162, py + 196, 0xFFFFFF, true);
        ctx.drawText(this.textRenderer,
                Text.literal("Wagered: " + AmountUtil.format(s.wageredVolume) + "   W/L: " + s.wins + "/" + s.losses)
                        .formatted(Formatting.GRAY),
                px + 8, py + 208, 0xFFFFFF, true);
    }

    @Override
    public boolean shouldPause() {
        return false; // keep the game running so chat keeps flowing
    }

    // ------------------------------------------------------------ helpers

    private ButtonWidget smallButton(String label, int x, int y, ButtonWidget.PressAction onPress) {
        return ButtonWidget.builder(Text.literal(label), onPress).dimensions(x, y, 20, 18).build();
    }

    private ButtonWidget colorButton(String label, Formatting color, int x, int y, int w, ButtonWidget.PressAction onPress) {
        return ButtonWidget.builder(Text.literal(label).formatted(color, Formatting.BOLD), onPress)
                .dimensions(x, y, w, 20).build();
    }

    private static String limit(long v) {
        return v == 0 ? "off" : AmountUtil.format(v);
    }

    private static String signed(long v) {
        return v < 0 ? "-" + AmountUtil.format(-v) : AmountUtil.format(v);
    }
}
