package dev.austun.casinohelperplus.logic;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import dev.austun.casinohelperplus.util.AmountUtil;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * The heart of the mod. Holds the live bet queue plus a full history log of
 * every resolved bet, and persists everything locally so a crash or restart
 * never loses your session. No network calls, ever.
 *
 * <p>The history log is the single source of truth: all running stats
 * (profit, wins, losses, per-player totals, the whale leaderboard) are
 * recomputed from it. That means an entry can be edited or deleted and every
 * number stays correct automatically.
 *
 * <p>Accounting per resolved bet:
 * <ul>
 *   <li>Win at multiplier M &rarr; profit += bet - round(bet * M).</li>
 *   <li>Loss &rarr; profit += bet (you keep it).</li>
 *   <li>Refund &rarr; profit unchanged, money returned.</li>
 *   <li>Tip &rarr; profit += bet, not counted as a wager.</li>
 * </ul>
 */
public class Session {

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final DateTimeFormatter STAMP = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    private static final DateTimeFormatter FILE_STAMP = DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss");
    private static Session INSTANCE;

    // ---- limits ----
    public long minBet = 0L;
    public long maxBet = 0L;

    // ---- persisted state ----
    public List<Bet> queue = new ArrayList<>();
    public List<HistoryEntry> history = new ArrayList<>();
    public long nextHistoryId = 1L;

    // ---- derived stats (recomputed from history + queue; not persisted) ----
    public transient long netProfit = 0L;
    public transient long heldAmount = 0L;
    public transient long wageredVolume = 0L;
    public transient long donationsTotal = 0L;
    public transient int wins = 0;
    public transient int losses = 0;
    public transient long biggestWinPayout = 0L;
    public transient long biggestBet = 0L;

    // ---- undo (one level, not persisted) ----
    private transient String lastSnapshot = null;

    /** Outcome of an action, so the UI / chat listener can give feedback. */
    public static class ActionResult {
        public final boolean success;
        public final String command; // command to copy/paste, or null
        public final String message;

        public ActionResult(boolean success, String command, String message) {
            this.success = success;
            this.command = command;
            this.message = message;
        }
    }

    // ------------------------------------------------------------------ access

    public static Session get() {
        if (INSTANCE == null) load();
        return INSTANCE;
    }

    public Bet activeBet() {
        return queue.isEmpty() ? null : queue.get(0);
    }

    public boolean canUndo() {
        return lastSnapshot != null;
    }

    // ------------------------------------------------------------------ stat recompute

    /** Rebuilds every derived stat from the history log and the live queue. */
    public void recompute() {
        netProfit = 0;
        wageredVolume = 0;
        donationsTotal = 0;
        wins = 0;
        losses = 0;
        biggestWinPayout = 0;
        biggestBet = 0;
        for (HistoryEntry h : history) {
            netProfit += h.houseNet;
            biggestBet = Math.max(biggestBet, h.bet);
            switch (h.result == null ? "" : h.result) {
                case "WIN" -> { wins++; wageredVolume += h.bet; biggestWinPayout = Math.max(biggestWinPayout, h.payout); }
                case "LOSE" -> { losses++; wageredVolume += h.bet; }
                case "TIP" -> donationsTotal += h.bet;
                default -> { } // REFUND: no stat effect
            }
        }
        heldAmount = 0;
        for (Bet b : queue) {
            heldAmount += b.amount;
            biggestBet = Math.max(biggestBet, b.amount);
        }
    }

    private HistoryEntry record(String player, long bet, String result, double multiplier) {
        HistoryEntry h = new HistoryEntry(nextHistoryId++, player, bet, result, multiplier);
        history.add(h);
        return h;
    }

    // ------------------------------------------------------------------ actions

    /** Called when a "paid you" chat line is detected. */
    public ActionResult onPayment(String player, long amount) {
        if (player == null || amount <= 0) {
            return new ActionResult(false, null, "Ignored an unreadable payment.");
        }
        snapshot();

        // Below the minimum: log as a tip, don't queue it.
        if (minBet > 0 && amount < minBet) {
            record(player, amount, "TIP", 0);
            recompute();
            save();
            return new ActionResult(true, null,
                    player + " tipped " + AmountUtil.format(amount) + " (below min).");
        }

        // Above the maximum: split into playable chunks.
        if (maxBet > 0 && amount > maxBet) {
            long remaining = amount;
            int chunks = 0;
            while (remaining > 0) {
                long chunk = Math.min(maxBet, remaining);
                queue.add(new Bet(player, chunk));
                remaining -= chunk;
                chunks++;
            }
            recompute();
            save();
            return new ActionResult(true, null,
                    "Split " + player + "'s " + AmountUtil.format(amount) + " into " + chunks + " bets.");
        }

        // Normal single bet.
        queue.add(new Bet(player, amount));
        recompute();
        save();
        return new ActionResult(true, null,
                "Queued " + player + " for " + AmountUtil.format(amount) + ".");
    }

    public ActionResult resolveWin(double multiplier) {
        Bet b = activeBet();
        if (b == null) return new ActionResult(false, null, "No active bet to resolve.");
        if (multiplier <= 0) return new ActionResult(false, null, "Multiplier must be greater than 0.");
        snapshot();

        queue.remove(0);
        HistoryEntry h = record(b.player, b.amount, "WIN", multiplier);
        ModConfig.get().lastMultiplier = trimMultiplier(multiplier);
        ModConfig.save();
        recompute();
        save();

        String command = buildCommand(b.player, h.payout);
        return new ActionResult(true, command,
                "WIN x" + trimMultiplier(multiplier) + " \u2192 pay " + b.player + " " + AmountUtil.format(h.payout));
    }

    public ActionResult resolveLose() {
        Bet b = activeBet();
        if (b == null) return new ActionResult(false, null, "No active bet to resolve.");
        snapshot();

        queue.remove(0);
        record(b.player, b.amount, "LOSE", 0);
        recompute();
        save();

        return new ActionResult(true, null,
                "LOSS \u2192 kept " + AmountUtil.format(b.amount) + " from " + b.player + ".");
    }

    public ActionResult refundActive() {
        Bet b = activeBet();
        if (b == null) return new ActionResult(false, null, "No active bet to refund.");
        snapshot();

        queue.remove(0);
        record(b.player, b.amount, "REFUND", 0);
        recompute();
        save();

        String command = buildCommand(b.player, b.amount);
        return new ActionResult(true, command,
                "Refund " + b.player + " " + AmountUtil.format(b.amount) + " (voided).");
    }

    public ActionResult donateActive() {
        Bet b = activeBet();
        if (b == null) return new ActionResult(false, null, "No active bet to mark.");
        snapshot();

        queue.remove(0);
        record(b.player, b.amount, "TIP", 0);
        recompute();
        save();

        return new ActionResult(true, null,
                "Marked " + b.player + "'s " + AmountUtil.format(b.amount) + " as a tip.");
    }

    /** One-hotkey payout: pay the current player a win at the last-used multiplier. */
    public ActionResult payCurrentWinner() {
        Bet b = activeBet();
        if (b == null) return new ActionResult(false, null, "No active bet to pay.");
        double m;
        try {
            m = Double.parseDouble(ModConfig.get().lastMultiplier.trim().replace("x", "").replace("X", ""));
        } catch (NumberFormatException e) {
            m = 2.0;
        }
        if (m <= 0) m = 2.0;
        return resolveWin(m);
    }

    // ------------------------------------------------------------------ history editing

    public HistoryEntry findHistory(long id) {
        for (HistoryEntry h : history) if (h.id == id) return h;
        return null;
    }

    /** Edits an entry in place, then recalculates every stat. */
    public boolean editHistory(long id, String result, long bet, double multiplier) {
        HistoryEntry h = findHistory(id);
        if (h == null) return false;
        snapshot();
        h.result = result;
        h.bet = Math.max(0, bet);
        h.multiplier = multiplier;
        h.recalc();
        recompute();
        save();
        return true;
    }

    public boolean deleteHistory(long id) {
        HistoryEntry h = findHistory(id);
        if (h == null) return false;
        snapshot();
        history.remove(h);
        recompute();
        save();
        return true;
    }

    // ------------------------------------------------------------------ per-player / leaderboard

    /** Rolls the whole history up per player, in first-seen order. */
    public Map<String, PlayerStats> playerStats() {
        Map<String, PlayerStats> map = new LinkedHashMap<>();
        for (HistoryEntry h : history) {
            if (h.player == null) continue;
            map.computeIfAbsent(h.player, PlayerStats::new).add(h);
        }
        return map;
    }

    /** Players ranked by total volume wagered (biggest whales first). */
    public List<PlayerStats> leaderboard() {
        List<PlayerStats> list = new ArrayList<>(playerStats().values());
        list.sort(Comparator
                .comparingLong((PlayerStats p) -> p.totalWagered).reversed()
                .thenComparing(p -> p.player, String.CASE_INSENSITIVE_ORDER));
        return list;
    }

    // ------------------------------------------------------------------ CSV export

    /**
     * Writes the history log and a per-player summary to timestamped CSV files
     * under {@code config/casinohelperplus/exports/}. Returns the folder path
     * as a string, or {@code null} on failure.
     */
    public String exportCsv() {
        try {
            Path dir = FabricLoader.getInstance().getConfigDir()
                    .resolve("casinohelperplus").resolve("exports");
            Files.createDirectories(dir);
            String stamp = LocalDateTime.now().format(FILE_STAMP);

            Path histFile = dir.resolve("history-" + stamp + ".csv");
            StringBuilder h = new StringBuilder();
            h.append("id,datetime,player,result,bet,multiplier,payout,house_net\n");
            for (HistoryEntry e : history) {
                h.append(e.id).append(',')
                 .append(LocalDateTime.ofInstant(java.time.Instant.ofEpochMilli(e.timestamp),
                         java.time.ZoneId.systemDefault()).format(STAMP)).append(',')
                 .append(csv(e.player)).append(',')
                 .append(e.result).append(',')
                 .append(e.bet).append(',')
                 .append(trimMultiplier(e.multiplier)).append(',')
                 .append(e.payout).append(',')
                 .append(e.houseNet).append('\n');
            }
            Files.writeString(histFile, h.toString());

            Path playerFile = dir.resolve("players-" + stamp + ".csv");
            StringBuilder p = new StringBuilder();
            p.append("player,bets,wagered,wins,losses,refunds,tips,tip_total,house_net,biggest_bet,biggest_payout\n");
            for (PlayerStats s : leaderboard()) {
                p.append(csv(s.player)).append(',')
                 .append(s.betCount).append(',')
                 .append(s.totalWagered).append(',')
                 .append(s.wins).append(',')
                 .append(s.losses).append(',')
                 .append(s.refunds).append(',')
                 .append(s.tips).append(',')
                 .append(s.tipTotal).append(',')
                 .append(s.houseNet).append(',')
                 .append(s.biggestBet).append(',')
                 .append(s.biggestPayout).append('\n');
            }
            Files.writeString(playerFile, p.toString());

            return dir.toString();
        } catch (IOException e) {
            return null;
        }
    }

    private static String csv(String v) {
        if (v == null) return "";
        if (v.contains(",") || v.contains("\"")) {
            return '"' + v.replace("\"", "\"\"") + '"';
        }
        return v;
    }

    // ------------------------------------------------------------------ limits

    public void adjustMin(long delta) { minBet = Math.max(0, minBet + delta); save(); }
    public void adjustMax(long delta) { maxBet = Math.max(0, maxBet + delta); save(); }
    public void setMin(long value) { minBet = Math.max(0, value); save(); }
    public void setMax(long value) { maxBet = Math.max(0, value); save(); }

    // ------------------------------------------------------------------ bulk ops

    /** Voids every pending bet without paying or keeping anything. */
    public void voidQueue() {
        snapshot();
        queue.clear();
        recompute();
        save();
    }

    /** Wipes stats, queue and history but keeps your min/max limits. */
    public void resetStats() {
        snapshot();
        queue.clear();
        history.clear();
        nextHistoryId = 1L;
        recompute();
        save();
    }

    public ActionResult undo() {
        if (lastSnapshot == null) {
            return new ActionResult(false, null, "Nothing to undo.");
        }
        Session prev = GSON.fromJson(lastSnapshot, Session.class);
        copyFrom(prev);
        lastSnapshot = null;
        recompute();
        save();
        return new ActionResult(true, null, "Undid the last action.");
    }

    // ------------------------------------------------------------------ helpers

    private String buildCommand(String player, long amount) {
        return ModConfig.get().payCommandTemplate
                .replace("%player%", player)
                .replace("%amount%", AmountUtil.toCommandNumber(amount));
    }

    public static String trimMultiplier(double m) {
        if (m == Math.floor(m)) return Long.toString((long) m);
        return String.format(Locale.US, "%.2f", m).replaceAll("0+$", "").replaceAll("\\.$", "");
    }

    private void snapshot() {
        lastSnapshot = GSON.toJson(this); // transient fields excluded automatically
    }

    private void copyFrom(Session o) {
        this.minBet = o.minBet;
        this.maxBet = o.maxBet;
        this.queue = o.queue != null ? o.queue : new ArrayList<>();
        this.history = o.history != null ? o.history : new ArrayList<>();
        this.nextHistoryId = o.nextHistoryId;
    }

    // ------------------------------------------------------------------ persistence

    private static Path path() {
        Path dir = FabricLoader.getInstance().getConfigDir().resolve("casinohelperplus");
        try {
            Files.createDirectories(dir);
        } catch (IOException ignored) {
        }
        return dir.resolve("session.json");
    }

    public static void load() {
        Path p = path();
        if (Files.exists(p)) {
            try (Reader r = Files.newBufferedReader(p)) {
                INSTANCE = GSON.fromJson(r, Session.class);
            } catch (Exception e) {
                INSTANCE = null;
            }
        }
        if (INSTANCE == null) {
            INSTANCE = new Session();
            ModConfig cfg = ModConfig.get();
            INSTANCE.minBet = cfg.defaultMinBet;
            INSTANCE.maxBet = cfg.defaultMaxBet;
        }
        if (INSTANCE.queue == null) INSTANCE.queue = new ArrayList<>();
        if (INSTANCE.history == null) INSTANCE.history = new ArrayList<>();
        if (INSTANCE.nextHistoryId < 1) INSTANCE.nextHistoryId = 1L;
        INSTANCE.recompute();
        save();
    }

    public static void save() {
        if (INSTANCE == null) return;
        try (Writer w = Files.newBufferedWriter(path())) {
            GSON.toJson(INSTANCE, w);
        } catch (IOException ignored) {
        }
    }
}
