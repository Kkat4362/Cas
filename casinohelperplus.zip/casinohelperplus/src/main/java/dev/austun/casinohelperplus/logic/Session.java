package dev.austun.casinohelperplus.logic;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import dev.austun.casinohelperplus.util.AmountUtil;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * The heart of the mod. Holds the live bet queue and running session stats,
 * does all the payout math, and persists everything locally so a crash or
 * restart never loses your session. No network calls, ever.
 *
 * <p>Accounting model (all realized on resolution):
 * <ul>
 *   <li>Payment received &rarr; money is "held" and counts toward wagered volume.</li>
 *   <li>Win at multiplier M &rarr; profit += bet - (bet * M).</li>
 *   <li>Loss &rarr; profit += bet (you keep it).</li>
 *   <li>Refund &rarr; money returned, removed from volume, profit unchanged.</li>
 *   <li>Donation &rarr; kept as profit, removed from wagered volume.</li>
 * </ul>
 */
public class Session {

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static Session INSTANCE;

    // ---- limits ----
    public long minBet = 0L;
    public long maxBet = 0L;

    // ---- live queue ----
    public List<Bet> queue = new ArrayList<>();

    // ---- running stats ----
    public long netProfit = 0L;
    public long heldAmount = 0L;
    public long wageredVolume = 0L;
    public long donationsTotal = 0L;
    public int wins = 0;
    public int losses = 0;
    public long biggestWinPayout = 0L;
    public long biggestBet = 0L;

    // ---- undo (one level, not persisted) ----
    private transient String lastSnapshot = null;

    /** Outcome of an action, so the UI / chat listener can give feedback. */
    public static class ActionResult {
        public final boolean success;
        public final String command; // command to copy/paste, or null
        public final String message;

        public ActionResult(boolean success, String command, String message) {
            this.success = success;
            this.command = command;
            this.message = message;
        }
    }

    // ------------------------------------------------------------------ access

    public static Session get() {
        if (INSTANCE == null) load();
        return INSTANCE;
    }

    public Bet activeBet() {
        return queue.isEmpty() ? null : queue.get(0);
    }

    public boolean canUndo() {
        return lastSnapshot != null;
    }

    // ------------------------------------------------------------------ actions

    /** Called when a "paid you" chat line is detected. */
    public ActionResult onPayment(String player, long amount) {
        if (player == null || amount <= 0) {
            return new ActionResult(false, null, "Ignored an unreadable payment.");
        }
        snapshot();
        biggestBet = Math.max(biggestBet, amount);

        // Below the minimum: treat as a donation, don't queue it.
        if (minBet > 0 && amount < minBet) {
            donationsTotal += amount;
            netProfit += amount;
            save();
            return new ActionResult(true, null,
                    player + " tipped " + AmountUtil.format(amount) + " (below min).");
        }

        // Above the maximum: split into playable chunks.
        if (maxBet > 0 && amount > maxBet) {
            long remaining = amount;
            int chunks = 0;
            while (remaining > 0) {
                long chunk = Math.min(maxBet, remaining);
                queue.add(new Bet(player, chunk));
                remaining -= chunk;
                chunks++;
            }
            heldAmount += amount;
            wageredVolume += amount;
            save();
            return new ActionResult(true, null,
                    "Split " + player + "'s " + AmountUtil.format(amount) + " into " + chunks + " bets.");
        }

        // Normal single bet.
        queue.add(new Bet(player, amount));
        heldAmount += amount;
        wageredVolume += amount;
        save();
        return new ActionResult(true, null,
                "Queued " + player + " for " + AmountUtil.format(amount) + ".");
    }

    public ActionResult resolveWin(double multiplier) {
        Bet b = activeBet();
        if (b == null) return new ActionResult(false, null, "No active bet to resolve.");
        if (multiplier <= 0) return new ActionResult(false, null, "Multiplier must be greater than 0.");
        snapshot();

        long payout = Math.round((double) b.amount * multiplier);
        queue.remove(0);
        netProfit += (b.amount - payout);
        heldAmount -= b.amount;
        wins++;
        biggestWinPayout = Math.max(biggestWinPayout, payout);
        save();

        String command = buildCommand(b.player, payout);
        return new ActionResult(true, command,
                "WIN x" + trimMultiplier(multiplier) + " \u2192 pay " + b.player + " " + AmountUtil.format(payout));
    }

    public ActionResult resolveLose() {
        Bet b = activeBet();
        if (b == null) return new ActionResult(false, null, "No active bet to resolve.");
        snapshot();

        queue.remove(0);
        netProfit += b.amount;
        heldAmount -= b.amount;
        losses++;
        save();

        return new ActionResult(true, null,
                "LOSS \u2192 kept " + AmountUtil.format(b.amount) + " from " + b.player + ".");
    }

    public ActionResult refundActive() {
        Bet b = activeBet();
        if (b == null) return new ActionResult(false, null, "No active bet to refund.");
        snapshot();

        queue.remove(0);
        heldAmount -= b.amount;
        wageredVolume -= b.amount; // does not count as a real wager
        save();

        String command = buildCommand(b.player, b.amount);
        return new ActionResult(true, command,
                "Refund " + b.player + " " + AmountUtil.format(b.amount) + " (voided).");
    }

    public ActionResult donateActive() {
        Bet b = activeBet();
        if (b == null) return new ActionResult(false, null, "No active bet to mark.");
        snapshot();

        queue.remove(0);
        heldAmount -= b.amount;
        wageredVolume -= b.amount;
        netProfit += b.amount;
        donationsTotal += b.amount;
        save();

        return new ActionResult(true, null,
                "Marked " + b.player + "'s " + AmountUtil.format(b.amount) + " as a donation.");
    }

    // ------------------------------------------------------------------ limits

    public void adjustMin(long delta) {
        minBet = Math.max(0, minBet + delta);
        save();
    }

    public void adjustMax(long delta) {
        maxBet = Math.max(0, maxBet + delta);
        save();
    }

    public void setMin(long value) {
        minBet = Math.max(0, value);
        save();
    }

    public void setMax(long value) {
        maxBet = Math.max(0, value);
        save();
    }

    // ------------------------------------------------------------------ bulk ops

    /** Voids every pending bet without paying or keeping anything. */
    public void voidQueue() {
        snapshot();
        long sum = 0;
        for (Bet b : queue) sum += b.amount;
        heldAmount -= sum;
        wageredVolume -= sum;
        queue.clear();
        save();
    }

    /** Wipes stats and queue but keeps your min/max limits. */
    public void resetStats() {
        snapshot();
        queue.clear();
        netProfit = 0;
        heldAmount = 0;
        wageredVolume = 0;
        donationsTotal = 0;
        wins = 0;
        losses = 0;
        biggestWinPayout = 0;
        biggestBet = 0;
        save();
    }

    public ActionResult undo() {
        if (lastSnapshot == null) {
            return new ActionResult(false, null, "Nothing to undo.");
        }
        Session prev = GSON.fromJson(lastSnapshot, Session.class);
        copyFrom(prev);
        lastSnapshot = null;
        save();
        return new ActionResult(true, null, "Undid the last action.");
    }

    // ------------------------------------------------------------------ helpers

    private String buildCommand(String player, long amount) {
        return ModConfig.get().payCommandTemplate
                .replace("%player%", player)
                .replace("%amount%", AmountUtil.toCommandNumber(amount));
    }

    private static String trimMultiplier(double m) {
        if (m == Math.floor(m)) return Long.toString((long) m);
        return String.format(Locale.US, "%.2f", m).replaceAll("0+$", "").replaceAll("\\.$", "");
    }

    private void snapshot() {
        lastSnapshot = GSON.toJson(this); // transient field excluded automatically
    }

    private void copyFrom(Session o) {
        this.minBet = o.minBet;
        this.maxBet = o.maxBet;
        this.queue = o.queue != null ? o.queue : new ArrayList<>();
        this.netProfit = o.netProfit;
        this.heldAmount = o.heldAmount;
        this.wageredVolume = o.wageredVolume;
        this.donationsTotal = o.donationsTotal;
        this.wins = o.wins;
        this.losses = o.losses;
        this.biggestWinPayout = o.biggestWinPayout;
        this.biggestBet = o.biggestBet;
    }

    // ------------------------------------------------------------------ persistence

    private static Path path() {
        Path dir = FabricLoader.getInstance().getConfigDir().resolve("casinohelperplus");
        try {
            Files.createDirectories(dir);
        } catch (IOException ignored) {
        }
        return dir.resolve("session.json");
    }

    public static void load() {
        Path p = path();
        if (Files.exists(p)) {
            try (Reader r = Files.newBufferedReader(p)) {
                INSTANCE = GSON.fromJson(r, Session.class);
            } catch (Exception e) {
                INSTANCE = null;
            }
        }
        if (INSTANCE == null) {
            INSTANCE = new Session();
            ModConfig cfg = ModConfig.get();
            INSTANCE.minBet = cfg.defaultMinBet;
            INSTANCE.maxBet = cfg.defaultMaxBet;
            save();
        }
        if (INSTANCE.queue == null) INSTANCE.queue = new ArrayList<>();
    }

    public static void save() {
        if (INSTANCE == null) return;
        try (Writer w = Files.newBufferedWriter(path())) {
            GSON.toJson(INSTANCE, w);
        } catch (IOException ignored) {
        }
    }
}
