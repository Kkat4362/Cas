# Casino Helper+

A **fully-local** casino-hosting assistant for DonutSMP, built with Fabric for
Minecraft **1.21.4** (Java 21). It watches chat for incoming bets, tracks a
queue, calculates payouts, splits oversized bets, and keeps live session
stats — all on your own machine, with **no external website and no account**.

This is an independent, from-scratch rewrite inspired by the original
"Casino Helper" concept, focused on reliability and privacy.

---

## Why this is better than the original

| Area | Original | Casino Helper+ |
|---|---|---|
| Data storage | Synced to a third-party site (`casinohelper.online`) you had to trust | 100% local JSON files, nothing leaves your PC |
| Works offline | No (needs the backend) | Yes |
| Survives restarts | — | Session + stats auto-saved and restored |
| Bet detection | Fixed | Configurable regex — fix it yourself if the server changes wording |
| Amount parsing | Basic | Handles `$1,000,000`, `2.5m`, `950k`, `1.2B`, `3T` |
| Mistakes | — | One-level **Undo** on every action |
| Limits | Left/right click a label | Clear −/+ buttons + a cycling step size |
| Human-in-the-loop | Clipboard | Clipboard (kept on purpose — you press Enter, so it's a helper, not a bot) |

> Kept deliberately: it **copies** the `/pay` command to your clipboard instead
> of auto-sending it. You stay in control, and it avoids anything that looks
> like chat automation.

---

## Controls

| Key | Action |
|---|---|
| **K** | Open the Casino Manager |
| **H** | Toggle the HUD overlay |
| **O** | Open Settings |

All rebindable in **Options → Controls → Key Binds → "Casino Helper+"**.

### In the manager
- **−/+** next to Min/Max change your limits by the current **Step** (click Step to cycle sizes).
- Type a **multiplier** (e.g. `2` or `2.5`) and hit **WIN** — the `/pay` command is copied to your clipboard. Then press `T`, `Ctrl+V`, `Enter`.
- **LOSE** keeps the bet. **Refund** voids it and copies a payback command. **Tip $** marks a payment as a donation (kept, but not counted as wagered).
- **Undo** reverses the last action. **Void All** clears the queue. **Reset** wipes stats (keeps limits).

### Auto behaviour
- A bet **under Min** is auto-treated as a tip (not queued).
- A bet **over Max** is auto-split into playable chunks (e.g. `$5M` at max `$2M` → `$2M, $2M, $1M`).

---

## Build it

### No-setup option — let GitHub build it for you
If you don't want to install anything, a cloud builder can compile the jar:
1. Make a free account at <https://github.com> if you don't have one.
2. Create a new **empty** repository (any name, e.g. `casinohelperplus`).
3. Upload every file from this folder into the repo (the **Add file → Upload files**
   button works, or drag the whole folder in). Make sure the hidden
   `.github/workflows/build.yml` goes up too.
4. Go to the repo's **Actions** tab. A build starts on its own; when the green
   check appears, open that run and download **`casinohelperplus-jar`** from the
   **Artifacts** section at the bottom.
5. Inside the download you'll find `casinohelperplus-1.0.0.jar` — that's your mod.
   (Ignore the `-sources.jar`; that's just the source code.)

The rest of the options below are for building on your own computer.

### Local build — you need JDK 21

### Easiest — IntelliJ IDEA Community (free)
1. Install IntelliJ IDEA Community Edition.
2. **File → Open** and select this `casinohelperplus` folder.
3. Let the Gradle sync finish (it downloads Minecraft + Fabric automatically).
4. Open the **Gradle** tool window → **Tasks → build → build**.
5. Your mod is at **`build/libs/casinohelperplus-1.0.0.jar`**.

To test it live without installing: run the **`runClient`** Gradle task.

### Command line
The Gradle wrapper is included, so you don't need Gradle pre-installed:
```bash
./gradlew build        # macOS / Linux
gradlew.bat build      # Windows
```
The first run downloads Gradle, Minecraft, and Fabric automatically.
Output: `build/libs/casinohelperplus-1.0.0.jar`.

### If a dependency version fails to resolve
Minecraft/Fabric version strings change over time. Open
<https://fabricmc.net/develop>, pick **1.21.4**, and copy the four values it
shows into `gradle.properties` (`yarn_mappings`, `loader_version`,
`fabric_version`, and confirm `minecraft_version`).

---

## Install the built mod
1. Install **Fabric Loader** for 1.21.4 and download **Fabric API**.
2. Drop **both** `fabric-api-*.jar` and `casinohelperplus-1.0.0.jar` into
   `.minecraft/mods/`.
3. Launch the Fabric 1.21.4 profile.

---

## Configuration
Files live in `.minecraft/config/casinohelperplus/`:
- `config.json` — toggles, default limits, and the **chat detection regex** + `/pay` command template.
- `session.json` — your live queue and stats (auto-managed).

Default detection pattern (group 1 = payer, group 2 = amount):
```
(?i)([A-Za-z0-9_]{2,16})\s+paid you\s+(\$?[0-9][0-9,.]*[kmbtKMBT]?)
```

---

*Not affiliated with DonutSMP, Mojang, or Microsoft. In-game virtual currency only.*
